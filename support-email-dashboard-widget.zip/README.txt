=== Support Email Dashboard Widget ===
Contributors: andypitechnology
Donate link: https://andypi.co.uk
Tags: dashboard, widget, support, email
Requires at least: 4.7.3
Tested up to: 1
Stable tag: 1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
Displays dashboard widget allowing the user to send a support request email to the site administrator.  
 
== Description ==

Designed for wordpress hosting companies or wordpress site administrators, this plugin  
allows any user to send a support request by email directly from their dashboard.
The dashboard widget title, message, email recipient and email subject can all be
specified in the plugin settings page.  

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/support-email-dashboard` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Settings->Support Email Dashboard screen to configure the plugin